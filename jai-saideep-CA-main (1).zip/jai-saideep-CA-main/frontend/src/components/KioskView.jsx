import { useState, useEffect } from 'react';
import axios from 'axios';
import { CloudRain, Users, AlertTriangle, Monitor } from 'lucide-react';
import { API_URL } from '../config';

export default function KioskView() {
  const [attractions, setAttractions] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const fetchData = async () => {
    try {
      const [attrRes, alertsRes] = await Promise.all([
        axios.get(`${API_URL}/attractions`),
        axios.get(`${API_URL}/alerts`)
      ]);
      setAttractions(attrRes.data);
      setAlerts(alertsRes.data.filter(a => a.severity === 'High' || a.severity === 'Critical'));
    } catch (error) {
       console.error("Kiosk Error:", error);
    }
  };

  useEffect(() => {
    fetchData();
    const dataInterval = setInterval(fetchData, 5000);
    const carouselInterval = setInterval(() => {
        setAttractions(prev => {
            if (prev.length === 0) return prev;
            setCurrentIndex(curr => (curr + 1) % prev.length);
            return prev;
        });
    }, 6000);

    return () => {
        clearInterval(dataInterval);
        clearInterval(carouselInterval);
    };
  }, []);

  if (attractions.length === 0) {
      return <div className="h-screen bg-black text-white flex justify-center items-center">Loading Signage Data...</div>;
  }

  const currentAttraction = attractions[currentIndex];
  // Calculate city wide average congestion
  const avgCongestion = Math.round(attractions.reduce((acc, curr) => acc + curr.current_crowd_level, 0) / attractions.length);

  return (
    <div className="fixed inset-0 z-50 bg-black text-white overflow-hidden font-sans flex flex-col">
      {/* Kiosk Header */}
      <div className="h-20 bg-slate-900 border-b border-slate-800 flex justify-between items-center px-8 shadow-2xl z-10">
          <div className="flex items-center gap-4">
              <Monitor className="text-blue-500" size={32} />
              <h1 className="text-3xl font-extrabold tracking-widest text-slate-100 uppercase">EcoTourIoT Kiosk</h1>
          </div>
          <div className="flex gap-12 items-center">
              <div className="text-center">
                  <div className="text-sm text-slate-400 uppercase font-bold tracking-widest mb-1">City Avg Congestion</div>
                  <div className={`text-2xl font-bold ${avgCongestion > 75 ? 'text-red-500' : avgCongestion > 40 ? 'text-yellow-400' : 'text-green-400'}`}>
                      {avgCongestion}%
                  </div>
              </div>
              <div className="text-center">
                  <div className="text-sm text-slate-400 uppercase font-bold tracking-widest mb-1">Live Weather</div>
                  <div className="flex items-center gap-2 text-xl font-bold text-blue-300">
                      <CloudRain size={24} /> 24°C
                  </div>
              </div>
              <div className="text-2xl font-bold font-mono tracking-widest text-slate-200">
                  {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit'})}
              </div>
          </div>
      </div>

      {/* Main Attraction Slide */}
      <div className="flex-1 relative transition-opacity duration-1000 ease-in-out">
          <img src={currentAttraction.image_url} alt="city_view" className="absolute inset-0 w-full h-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
          
          <div className="absolute bottom-16 left-16 right-16">
              <h2 className="text-7xl font-extrabold text-white drop-shadow-2xl mb-6">{currentAttraction.name}</h2>
              
              <div className="flex gap-8">
                  <div className="bg-slate-900/80 backdrop-blur-md p-8 rounded-3xl border border-slate-700/50 w-96 shadow-2xl">
                    <h3 className="text-uppercase tracking-widest text-slate-300 font-bold mb-4 flex items-center gap-3">
                        <Users className="text-blue-400" size={24} /> LIVE CROWD STATUS
                    </h3>
                    <div className="flex items-end gap-2 mb-4">
                        <span className={`text-6xl font-black ${currentAttraction.current_crowd_level > 80 ? 'text-red-500' : currentAttraction.current_crowd_level > 50 ? 'text-yellow-400' : 'text-green-500'}`}>
                            {currentAttraction.current_crowd_level}%
                        </span>
                        <span className="text-xl text-slate-400 font-bold pb-2">Capacity</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden shadow-inner">
                        <div 
                        className={`h-full rounded-full transition-all duration-1000 ${currentAttraction.current_crowd_level > 80 ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.7)]' : currentAttraction.current_crowd_level > 50 ? 'bg-yellow-400' : 'bg-green-500'}`} 
                        style={{ width: `${currentAttraction.current_crowd_level}%` }}
                        ></div>
                    </div>
                  </div>

                  {currentAttraction.current_crowd_level >= 80 && (
                      <div className="bg-red-900/80 backdrop-blur-md p-8 rounded-3xl border border-red-500/50 flex-1 flex items-center shadow-2xl animate-pulse">
                          <div>
                              <div className="flex items-center gap-4 text-red-400 mb-2">
                                  <AlertTriangle size={40} />
                                  <h3 className="text-3xl font-bold uppercase tracking-widest">Congestion Alert</h3>
                              </div>
                              <p className="text-xl text-red-200">This area is currently experiencing high crowd density. Please consider alternative transport routes or visit at a later time.</p>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      </div>

      {/* Global Ticker */}
      {alerts.length > 0 && (
          <div className="h-16 bg-red-600 flex items-center overflow-hidden z-20">
              <div className="whitespace-nowrap text-2xl font-bold text-white uppercase tracking-widest flex items-center gap-8 animate-[marquee_15s_linear_infinite]">
                 {alerts.map((alert, i) => (
                     <span key={i} className="flex items-center gap-2"><AlertTriangle size={24} /> {alert.message}</span>
                 ))}
                 {alerts.map((alert, i) => (
                     <span key={i+"dup"} className="flex items-center gap-2"><AlertTriangle size={24} /> {alert.message}</span>
                 ))}
              </div>
          </div>
      )}
    </div>
  );
}
