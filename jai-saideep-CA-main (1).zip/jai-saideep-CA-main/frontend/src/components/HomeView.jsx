import { ArrowRight, Globe, ShieldCheck, Zap } from 'lucide-react';

export default function HomeView({ onGetStarted }) {
  return (
    <div className="space-y-16 animate-in fade-in duration-700">
      
      {/* Hero Section */}
      <section className="relative rounded-3xl overflow-hidden bg-slate-900 shadow-2xl">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1200&auto=format&fit=crop" 
            alt="Smart City" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 to-transparent"></div>
        </div>
        
        <div className="relative z-10 px-8 py-20 lg:py-32 max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
            Shaping the Future of <span className="text-blue-400">Smart Tourism</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-300 mb-8 leading-relaxed">
            Experience destinations like never before. EcoTourIoT integrates smart sensors, AI-driven data analytics, and real-time connectivity to ensure your journey is safe, efficient, and unforgettable.
          </p>
          <button 
            onClick={onGetStarted}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 px-8 rounded-full text-lg transition-transform transform hover:scale-105 flex items-center gap-2 shadow-lg shadow-blue-500/30"
          >
            Access Live Dashboard <ArrowRight size={20} />
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
        <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-lg outline outline-1 outline-slate-100 dark:outline-slate-700 hover:-translate-y-2 transition-transform">
          <div className="bg-blue-100 dark:bg-blue-900/30 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <Globe className="text-blue-600 dark:text-blue-400" size={28} />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Seamless Mobility</h3>
          <p className="text-slate-600 dark:text-slate-400">Navigate city transport networks with real-time congestion data, ensuring you never wait in long lines again.</p>
        </div>

        <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-lg outline outline-1 outline-slate-100 dark:outline-slate-700 hover:-translate-y-2 transition-transform">
          <div className="bg-green-100 dark:bg-green-900/30 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <ShieldCheck className="text-green-600 dark:text-green-400" size={28} />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Enhanced Safety</h3>
          <p className="text-slate-600 dark:text-slate-400">Our IoT network proactively monitors crowd densities to prevent dangerous overcrowding at major tourist hotspots.</p>
        </div>

        <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-lg outline outline-1 outline-slate-100 dark:outline-slate-700 hover:-translate-y-2 transition-transform">
          <div className="bg-purple-100 dark:bg-purple-900/30 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <Zap className="text-purple-600 dark:text-purple-400" size={28} />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Predictive AI</h3>
          <p className="text-slate-600 dark:text-slate-400">Stakeholders utilize historical data to predict peaks and proactively deploy transit fleets before bottlenecks happen.</p>
        </div>
      </section>

    </div>
  );
}
