import { useState } from 'react';
import { BrainCircuit, TrendingUp, BarChart3, Clock, Monitor } from 'lucide-react';

export default function PredictiveAnalyticsView() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPlan, setShowPlan] = useState(false);
  
  // Dummy data representing peak crowds across the week
  const historicalData = [
    { day: 'Mon', peak: 45, predicted: 50 },
    { day: 'Tue', peak: 30, predicted: 35 },
    { day: 'Wed', peak: 85, predicted: 80 }, // Example peak
    { day: 'Thu', peak: 55, predicted: 60 },
    { day: 'Fri', peak: 95, predicted: 90 }, // Example peak
    { day: 'Sat', peak: 98, predicted: 100 }, // Example peak
    { day: 'Sun', peak: 70, predicted: 75 },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-xl flex items-center justify-between">
        <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                <BrainCircuit className="text-purple-400" size={28} /> AI Predictive Analytics Module
            </h2>
            <p className="text-slate-400 mt-2">Correlating historical IoT sensor data with machine learning to predict and prevent future city traffic bottlenecks.</p>
        </div>
        <div className="hidden md:block bg-purple-900/40 p-4 rounded-xl border border-purple-500/30">
            <div className="text-xs text-purple-300 font-bold uppercase tracking-wider mb-1">Model Accuracy</div>
            <div className="text-3xl text-white font-extrabold flex items-end gap-1">94.2<span className="text-sm text-purple-400 mb-1">%</span></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Peak Recording Chart */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl outline outline-1 outline-slate-100 dark:outline-slate-700 shadow-md">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2">
              <BarChart3 className="text-blue-500" /> 7-Day Peak Traffic Recording
          </h3>
          
          <div className="flex items-end gap-4 h-64 mt-4 px-2">
            {historicalData.map((data) => (
                <div key={data.day} className="flex-1 flex flex-col items-center justify-end h-full gap-2 relative group">
                    {/* Tooltip */}
                    <div className="absolute -top-10 bg-slate-900 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                        {data.peak}% Peak
                    </div>
                    {/* Bar */}
                    <div 
                        className={`w-full rounded-t-sm transition-all duration-500 ${data.peak > 80 ? 'bg-red-500' : data.peak > 50 ? 'bg-yellow-400' : 'bg-green-500'}`}
                        style={{ height: `${data.peak}%` }}
                    ></div>
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">{data.day}</span>
                </div>
            ))}
          </div>
        </div>

        {/* Future Prediction Panel */}
        <div className="space-y-6">
            <div className="bg-purple-50 dark:bg-slate-800/50 outline outline-1 outline-purple-200 dark:outline-purple-900/50 p-6 rounded-2xl shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2">
                    <TrendingUp className="text-purple-600 dark:text-purple-400" /> Next 24 Hours Forecast
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">Our cross-impact analysis indicates severe transit bottlenecks expected tomorrow afternoon.</p>
                
                <div className="space-y-4">
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <Clock className="text-slate-400" size={20} />
                            <div>
                                <h4 className="font-bold text-slate-700 dark:text-slate-200">14:00 - 16:30</h4>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Marina Bay Central</p>
                            </div>
                        </div>
                        <span className="text-red-600 dark:text-red-400 font-bold bg-red-100 dark:bg-red-900/30 px-2 py-1 rounded text-sm">92% Predicted</span>
                    </div>

                    <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <Clock className="text-slate-400" size={20} />
                            <div>
                                <h4 className="font-bold text-slate-700 dark:text-slate-200">17:00 - 19:00</h4>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Sagrada Familia Transit</p>
                            </div>
                        </div>
                        <span className="text-yellow-600 dark:text-yellow-400 font-bold bg-yellow-100 dark:bg-yellow-900/30 px-2 py-1 rounded text-sm">75% Predicted</span>
                    </div>
                </div>
            </div>

            {!showPlan ? (
                <button 
                  onClick={() => {
                      setIsGenerating(true);
                      setTimeout(() => {
                          setIsGenerating(false);
                          setShowPlan(true);
                      }, 2500);
                  }}
                  className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold py-4 rounded-xl shadow-lg hover:-translate-y-1 transition-transform border border-slate-700 flex items-center justify-center gap-2"
                >
                    {isGenerating ? (
                        <>
                            <BrainCircuit className="animate-spin text-purple-400" /> Running AI Simulation...
                        </>
                    ) : (
                        <>Generate Smart Deployment Plan</>
                    )}
                </button>
            ) : (
                <div className="bg-green-50 dark:bg-green-900/20 outline outline-1 outline-green-200 dark:outline-green-800 p-6 rounded-2xl animate-in zoom-in-95 duration-500">
                    <h3 className="font-bold text-green-800 dark:text-green-400 mb-4 flex items-center gap-2">
                        <Monitor className="text-green-600 dark:text-green-500" /> AI Recommended Action Plan
                    </h3>
                    <ul className="space-y-3">
                        <li className="text-sm text-green-700 dark:text-green-300 flex items-start gap-2">
                            <span className="font-bold shrink-0">14:00</span> 
                            Dispatch 12 autonomous relief shuttles to Marina Bay Transit Hub.
                        </li>
                        <li className="text-sm text-green-700 dark:text-green-300 flex items-start gap-2">
                            <span className="font-bold shrink-0">15:30</span> 
                            Automatically re-route Google Maps / IoT navigation away from Central Plaza.
                        </li>
                        <li className="text-sm text-green-700 dark:text-green-300 flex items-start gap-2">
                            <span className="font-bold shrink-0">17:00</span> 
                            Deploy 4 Crowd-Safety Officer teams to Sagrada Familia main entrance.
                        </li>
                    </ul>
                    <button 
                      onClick={() => setShowPlan(false)}
                      className="mt-6 w-full bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded-lg text-sm transition-colors"
                    >
                        Acknowledge & Execute Command
                    </button>
                </div>
            )}
        </div>

      </div>
    </div>
  );
}
