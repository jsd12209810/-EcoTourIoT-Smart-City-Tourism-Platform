import { useState, useEffect } from 'react';
import axios from 'axios';
import { Activity, Send, AlertOctagon } from 'lucide-react';
import { API_URL } from '../config';

export default function AdminView() {
  const [attractions, setAttractions] = useState([]);
  const [alertForm, setAlertForm] = useState({ message: '', location: 'Citywide', severity: 'High' });
  const [statusMsg, setStatusMsg] = useState('');

  const fetchAttractions = async () => {
    try {
      const res = await axios.get(`${API_URL}/attractions`);
      setAttractions(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchAttractions();
    const interval = setInterval(fetchAttractions, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSendAlert = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API_URL}/alerts`, alertForm);
      setStatusMsg('Alert broadcasted to all tourists successfully!');
      setAlertForm({ ...alertForm, message: '' });
      setTimeout(() => setStatusMsg(''), 3000);
    } catch (error) {
      setStatusMsg('Failed to send alert.');
    }
  };

  const getStatusDot = (level) => {
      if(level > 80) return <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></span>;
      if(level > 50) return <span className="w-3 h-3 rounded-full bg-yellow-500"></span>;
      return <span className="w-3 h-3 rounded-full bg-green-500"></span>;
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-500">
      
      {/* Main Stakeholder Chart / List */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl outline outline-1 outline-slate-100 dark:outline-slate-700 shadow-md">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-slate-800 dark:text-white">
            <Activity className="text-blue-500" /> City Overview Monitor
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-900/50 text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                  <th className="p-3">Status</th>
                  <th className="p-3">Location</th>
                  <th className="p-3">Current Crowd Density</th>
                  <th className="p-3">Safety Action</th>
                </tr>
              </thead>
              <tbody>
                {attractions.map(attr => (
                  <tr key={attr._id} className="border-b border-slate-100 dark:border-slate-700 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                    <td className="p-3 justify-center items-center">{getStatusDot(attr.current_crowd_level)}</td>
                    <td className="p-3 font-medium text-slate-800 dark:text-slate-200">{attr.name}</td>
                    <td className="p-3">
                        <div className="w-full max-w-[200px] bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-1">
                            <div className={`h-2 rounded-full ${attr.current_crowd_level > 80 ? 'bg-red-500' : attr.current_crowd_level > 50 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{width: `${attr.current_crowd_level}%`}}></div>
                        </div>
                        <span className="text-xs text-slate-500 dark:text-slate-400 mt-1 inline-block">{attr.current_crowd_level}% capacity</span>
                    </td>
                    <td className="p-3">
                        {attr.current_crowd_level > 80 ? (
                            <span className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 px-2 py-1 rounded text-xs font-semibold">Deploy Transit</span>
                        ) : (
                            <span className="text-slate-400 dark:text-slate-500 text-xs">Monitoring</span>
                        )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Manual Alert Broadcast Panel */}
      <div className="space-y-6">
        <div className="bg-slate-900 dark:bg-slate-950 text-white p-6 rounded-xl shadow-lg border border-slate-800 dark:border-slate-700">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <AlertOctagon className="text-red-400" /> Broadcast Alert
            </h2>
            <p className="text-sm text-slate-400 mb-6">Send manual notifications to tourists regarding rerouting, transport changes, or safety procedures.</p>
            
            <form onSubmit={handleSendAlert} className="space-y-4">
                <div>
                    <label className="block text-xs uppercase tracking-wider text-slate-400 mb-1">Target Location</label>
                    <select 
                        className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none"
                        value={alertForm.location}
                        onChange={(e) => setAlertForm({...alertForm, location: e.target.value})}
                    >
                        <option>Citywide</option>
                        {attractions.map(attr => (
                            <option key={attr._id} value={attr.name}>{attr.name}</option>
                        ))}
                    </select>
                </div>
                
                <div>
                    <label className="block text-xs uppercase tracking-wider text-slate-400 mb-1">Alert Message</label>
                    <textarea 
                        required
                        className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-white min-h-[100px] focus:ring-2 focus:ring-blue-500 outline-none placeholder:text-slate-500"
                        placeholder="e.g. Extra shuttle buses deployed to Marina Bay to ease congestion..."
                        value={alertForm.message}
                        onChange={(e) => setAlertForm({...alertForm, message: e.target.value})}
                    ></textarea>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition-colors flex items-center justify-center gap-2"
                >
                    <Send size={18} /> Broadcast Now
                </button>
                
                {statusMsg && (
                    <div className="text-sm text-green-400 mt-2 text-center bg-green-900 bg-opacity-30 p-2 rounded">
                        {statusMsg}
                    </div>
                )}
            </form>
        </div>
      </div>
    </div>
  );
}
