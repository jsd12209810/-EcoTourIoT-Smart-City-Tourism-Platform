import { useState, useEffect } from 'react';
import axios from 'axios';
import { Bell, MapPin, Users, AlertTriangle, X, TrendingUp, Clock, Activity, ShieldCheck } from 'lucide-react';
import { API_URL } from '../config';

export default function TouristView() {
  const [attractions, setAttractions] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [sosSent, setSosSent] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [attrRes, alertsRes] = await Promise.all([
        axios.get(`${API_URL}/attractions`),
        axios.get(`${API_URL}/alerts`)
      ]);
      setAttractions(attrRes.data);
      setAlerts(alertsRes.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Poll for real-time simulated IoT data every 5 seconds
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const getCrowdColor = (level) => {
    if (level < 40) return 'bg-green-500 text-green-800 bg-opacity-20';
    if (level < 75) return 'bg-yellow-500 text-yellow-800 bg-opacity-20';
    return 'bg-red-500 text-red-800 bg-opacity-20';
  };

  const getProgressBarColor = (level) => {
    if (level < 40) return 'bg-green-500';
    if (level < 75) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const handleSosTrigger = async () => {
    try {
      // Render link synchronously first so browser pop-up blockers don't block it
      window.open("https://www.police.gov.sg", "_blank");

      await axios.post(`${API_URL}/alerts`, {
        message: "CRITICAL: Emergency SOS Beacon Triggered from Tourist Device!",
        severity: "Critical",
        location: "Tourist Network"
      });
      setSosSent(true);
      setTimeout(() => setSosSent(false), 5000);
    } catch (error) {
      console.error("SOS failed", error);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 relative">
      
      {/* City Alerts Banner */}
      {alerts.length > 0 && (
        <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4 rounded-r-md shadow-sm">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-red-500 mt-1" size={24} />
            <div>
              <h3 className="text-red-800 dark:text-red-400 font-semibold text-lg">City-Wide Transport & Crowd Alerts</h3>
              <ul className="mt-2 space-y-2">
                {alerts.slice(0, 3).map((alert, idx) => (
                  <li key={idx} className="text-red-700 dark:text-red-300 text-sm flex gap-2">
                     <span className="font-bold">[{new Date(alert.timestamp).toLocaleTimeString()}]</span>
                     {alert.message}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Attractions Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-6 text-slate-800 dark:text-white flex items-center gap-2">
          <MapPin className="text-blue-500" /> City Attractions Live Status
        </h2>
        
        {loading ? (
            <div className="text-slate-500 dark:text-slate-400">Loading IoT sensor data...</div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pointer-events-auto">
            {attractions.map(attr => (
                <div 
                    key={attr._id} 
                    onClick={() => setSelectedCard(attr)}
                    className="bg-white dark:bg-slate-800 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-700 overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:border-blue-300 dark:hover:border-blue-500 cursor-pointer"
                >
                <div className="h-48 overflow-hidden">
                    <img src={attr.image_url} alt={attr.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-5">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{attr.name}</h3>
                    <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 line-clamp-2">{attr.description}</p>
                    
                    <div className={`p-3 rounded-md flex items-center justify-between mb-4 ${getCrowdColor(attr.current_crowd_level)}`}>
                        <div className="flex items-center gap-2 font-medium">
                            <Users size={18} /> Crowd Density
                        </div>
                        <span className="font-bold text-lg">{attr.current_crowd_level}%</span>
                    </div>

                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 overflow-hidden">
                        <div 
                        className={`h-2.5 rounded-full transition-all duration-1000 ${getProgressBarColor(attr.current_crowd_level)}`} 
                        style={{ width: `${attr.current_crowd_level}%` }}
                        ></div>
                    </div>
                    
                    {attr.current_crowd_level >= 80 && (
                        <p className="mt-3 text-red-600 dark:text-red-400 text-xs font-semibold flex items-center gap-1">
                            <AlertTriangle size={14} /> High congestion. Avoid if possible.
                        </p>
                    )}
                </div>
                </div>
            ))}
            </div>
        )}
      </div>

      {/* Floating SOS Button */}
      <div className="fixed bottom-8 right-8 z-50">
          <button 
            onClick={handleSosTrigger} 
            disabled={sosSent}
            className={`rounded-full p-4 shadow-[0_0_20px_rgba(239,68,68,0.5)] transition-transform hover:scale-110 flex items-center gap-2 ${sosSent ? 'bg-slate-800 text-slate-400' : 'bg-red-600 hover:bg-red-500 text-white animate-pulse'}`}
          >
              {sosSent ? (
                  <span className="font-bold text-sm px-2">SOS Broadcasted to City Admin</span>
              ) : (
                  <>
                    <AlertTriangle size={32} />
                    <p className="text-sm font-bold opacity-80 mt-1 uppercase tracking-widest">{sosSent ? 'Emergency Dispatched' : 'Tap for Emergency Response'}</p>
                  </>
              )}
          </button>
      </div>

      {/* Expanded Analytics Modal */}
      {selectedCard && (
          <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="bg-white dark:bg-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
                  
                  {/* Modal Header Cover */}
                  <div className="relative h-48 md:h-64 shrink-0">
                      <img src={selectedCard.image_url} className="w-full h-full object-cover" alt={selectedCard.name} />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent flex flex-col justify-end p-6">
                          <h2 className="text-3xl font-bold text-white mb-2">{selectedCard.name}</h2>
                          <div className="flex gap-4 mb-2">
                              {selectedCard.current_crowd_level > 70 ? (
                                  <span className="bg-red-500/90 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 backdrop-blur-md border border-red-400">
                                      <AlertTriangle size={14}/> High Congestion
                                  </span>
                              ) : (
                                  <span className="bg-green-500/90 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 backdrop-blur-md border border-green-400">
                                      <ShieldCheck size={14}/> Optimal Conditions
                                  </span>
                              )}
                              <span className="bg-blue-500/90 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 backdrop-blur-md border border-blue-400">
                                  <TrendingUp size={14}/> Live IoT Stream
                              </span>
                          </div>
                      </div>
                      <button 
                          onClick={() => setSelectedCard(null)} 
                          className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white p-2 rounded-full backdrop-blur-md transition-colors"
                      >
                          <X size={20} />
                      </button>
                  </div>

                  {/* Modal Content / Analytics */}
                  <div className="p-6 overflow-y-auto">
                      <p className="text-slate-600 dark:text-slate-300 mb-6 flex bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-100 dark:border-slate-700 italic">
                          "{selectedCard.description}"
                      </p>

                      <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-4">Deep Insight Analytics</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          
                          {/* Live Density Metric */}
                          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex items-center gap-4 bg-white dark:bg-slate-800 shadow-sm relative overflow-hidden">
                              <div className={`absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r ${selectedCard.current_crowd_level > 70 ? 'from-red-500 to-orange-400' : selectedCard.current_crowd_level > 40 ? 'from-orange-500 to-amber-400' : 'from-green-500 to-emerald-400'}`}></div>
                              <div className="bg-slate-100 dark:bg-slate-700 p-3 rounded-full text-slate-600 dark:text-slate-300">
                                  <Users size={28} />
                              </div>
                              <div>
                                  <p className="text-xs uppercase tracking-widest font-bold text-slate-400">Crowd Density</p>
                                  <div className="text-2xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                                      {selectedCard.current_crowd_level}%
                                      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Capacity</span>
                                  </div>
                              </div>
                          </div>

                          {/* Predicted Peak */}
                          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex items-center gap-4 bg-white dark:bg-slate-800 shadow-sm relative overflow-hidden">
                              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-400"></div>
                              <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-full text-blue-600 dark:blue-400">
                                  <Clock size={28} />
                              </div>
                              <div>
                                  <p className="text-xs uppercase tracking-widest font-bold text-slate-400">Peak Forecast</p>
                                  <div className="text-2xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                                      14:30 
                                      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">EST</span>
                                  </div>
                                  <p className="text-xs text-blue-600 font-bold">Expect +12% Surge</p>
                              </div>
                          </div>

                          {/* Foot Traffic Speed */}
                          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex items-center gap-4 bg-white dark:bg-slate-800 shadow-sm relative overflow-hidden">
                              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-400"></div>
                              <div className="bg-purple-50 dark:bg-purple-900/30 p-3 rounded-full text-purple-600 dark:text-purple-400">
                                  <Activity size={28} />
                              </div>
                              <div>
                                  <p className="text-xs uppercase tracking-widest font-bold text-slate-400">Flow Rate</p>
                                  <div className="text-2xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                                      {Math.max(1.2, (5 - (selectedCard.current_crowd_level/20))).toFixed(1)} 
                                      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">m/s</span>
                                  </div>
                                  <p className="text-xs text-purple-600 font-bold">Average walking speed</p>
                              </div>
                          </div>

                          {/* Sensor Node Health */}
                          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex items-center gap-4 bg-white dark:bg-slate-800 shadow-sm relative overflow-hidden">
                              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-teal-500 to-cyan-400"></div>
                              <div className="bg-teal-50 dark:bg-teal-900/30 p-3 rounded-full text-teal-600 dark:text-teal-400">
                                  <MapPin size={28} />
                              </div>
                              <div>
                                  <p className="text-xs uppercase tracking-widest font-bold text-slate-400">IoT Grid Status</p>
                                  <div className="text-2xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                                      99.9%
                                  </div>
                                  <p className="text-xs text-teal-600 font-bold">14 Active Edge Nodes</p>
                              </div>
                          </div>

                      </div>
                      
                      <button onClick={() => setSelectedCard(null)} className="mt-8 w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold py-4 rounded-xl hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors">
                          Return to Map
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}
