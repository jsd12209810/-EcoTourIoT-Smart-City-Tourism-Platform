import { useState, useEffect } from 'react';
import axios from 'axios';
import { Bus, Star, ThumbsUp, Send, Train, Zap, CreditCard, Wallet, QrCode } from 'lucide-react';
import { API_URL } from '../config';

export default function MobilityFeedbackView() {
  const [rating, setRating] = useState(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [submitted, setSubmitted] = useState(false);
  
  // Dynamic Rerouting State
  const [attractions, setAttractions] = useState([]);
  
  // Route Selection State
  const [fromLoc, setFromLoc] = useState('');
  const [toLoc, setToLoc] = useState('');

  // Ticketing State
  const [showWallet, setShowWallet] = useState(false);
  const [walletBalance, setWalletBalance] = useState(42.50);
  const [purchasedTicket, setPurchasedTicket] = useState(null);

  useEffect(() => {
    const fetchAttractions = async () => {
      try {
        const res = await axios.get(`${API_URL}/attractions`);
        setAttractions(res.data);
        if (res.data.length >= 2 && !fromLoc) {
            setFromLoc(res.data[0].name);
            setToLoc(res.data[1].name);
        }
      } catch(err) {
        console.error(err);
      }
    };
    fetchAttractions();
    const interval = setInterval(fetchAttractions, 5000);
    return () => clearInterval(interval);
  }, [fromLoc]); // Added fromLoc so we don't overwrite if user changed it. Wait, no, we just check !fromLoc in the condition.

  const cityLocations = attractions.map(a => a.name);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        await axios.post(`${API_URL}/feedback`, { rating, text: feedbackText });
        setSubmitted(true);
        setTimeout(() => setSubmitted(false), 4000);
        setRating(0);
        setFeedbackText('');
    } catch(err) {
        console.error("Failed to save feedback", err);
    }
  };

  const handleBookTicket = (route, price) => {
      if (walletBalance >= price) {
          setWalletBalance(prev => prev - price);
          setPurchasedTicket(route);
          setShowWallet(true);
      } else {
          alert("Insufficient wallet balance!");
      }
  };

  const destinationData = attractions.find(a => a.name === toLoc);
  const isDestinationCongested = destinationData && destinationData.current_crowd_level > 70;

  // Generate dynamic, deterministic fare and time based on string length math
  const seed = fromLoc.length + toLoc.length;
  const isSameLocation = fromLoc === toLoc;
  const distance = isSameLocation ? 0 : (seed * 0.4).toFixed(1);
  const timeMod = isSameLocation ? 0 : (seed % 10) + 5;
  const priceMod = isSameLocation ? 0 : (seed % 5) * 0.45;

  const metroPrice = 1.50 + priceMod;
  const busPrice = 1.00 + (priceMod * 0.5);
  const taxiPrice = 5.00 + (priceMod * 2.5);

  // Dynamically determine available transport modes for this specific route
  const isMetroAvailable = (seed % 3) !== 0;
  const isMonorailAvailable = (seed % 2) === 0;

  const handleDownloadTicket = () => {
      // Use a public QR code generator API to create a real QR image for the PDF
      const qrData = encodeURIComponent(`EcoTourIoT Transit\nTicket: ${purchasedTicket}\nRoute: ${fromLoc} to ${toLoc}\nDist: ${distance}km`);
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${qrData}`;

      const ticketHtml = `
          <html>
              <head><style>body { font-family: monospace; text-align: center; padding: 40px; border: 2px dashed black; max-width: 400px; margin: 40px auto; }</style></head>
              <body>
                  <h2>EcoTour IoT Transit</h2>
                  <h1>${purchasedTicket} Valid</h1>
                  <p><strong>From:</strong> ${fromLoc}</p>
                  <p><strong>To:</strong> ${toLoc}</p>
                  <p>Distance: ${distance}km</p>
                  <hr style="margin: 20px 0; border: 1px dashed black;" />
                  <div style="margin: 20px 0;">
                      <img src="${qrUrl}" alt="Ticket QR Code" />
                  </div>
                  <p>Save this receipt to your device</p>
                  <script>window.print()</script>
              </body>
          </html>
      `;
      const blob = new Blob([ticketHtml], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {showWallet && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white dark:bg-slate-800 max-w-sm w-full rounded-3xl overflow-hidden shadow-2xl relative text-center pb-8 border border-slate-200 dark:border-slate-700">
                  <div className="bg-gradient-to-br from-blue-600 to-purple-600 h-32 flex items-center justify-center relative">
                     <button onClick={() => setShowWallet(false)} className="absolute top-4 right-4 text-white hover:text-slate-300 font-bold">X</button>
                     <Wallet className="text-white drop-shadow-md" size={48} />
                  </div>
                  <h2 className="text-xl font-bold mt-6 text-slate-800 dark:text-white">Seamless Transit Card</h2>
                  <p className="text-slate-500 dark:text-slate-400 mb-6 font-mono text-sm">Remaining Balance: <span className="font-bold text-green-500">${walletBalance.toFixed(2)}</span></p>
                  
                  {purchasedTicket ? (
                      <div className="mx-8 bg-blue-50 dark:bg-slate-900 border-2 border-dashed border-blue-200 dark:border-slate-600 rounded-xl p-6 relative">
                         <div className="flex flex-col gap-1 text-xs text-slate-500 font-bold mb-4 bg-slate-100 dark:bg-slate-800 p-2 rounded-md">
                             <div className="flex justify-between"><span>Origin:</span> <span className="text-slate-800 dark:text-white truncate max-w-[120px]">{fromLoc}</span></div>
                             <div className="flex justify-between"><span>Dest:</span> <span className="text-slate-800 dark:text-white truncate max-w-[120px]">{toLoc}</span></div>
                         </div>
                         <div className="flex justify-center mb-4"><QrCode size={120} className="text-slate-800 dark:text-white" /></div>
                         <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">{purchasedTicket}</h3>
                         <p className="text-xs text-green-600 dark:text-green-400 mt-2 font-bold flex items-center justify-center gap-1"><Zap size={12}/> Active & Valid</p>
                         
                         <button 
                             onClick={handleDownloadTicket}
                             className="mt-6 w-full text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white py-2 rounded-lg transition-colors border border-slate-600"
                         >
                             Download PDF Pass
                         </button>
                      </div>
                  ) : (
                      <p className="text-slate-500">No active tickets.</p>
                  )}
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Smart Mobility Section */}
        <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-md outline outline-1 outline-slate-100 dark:outline-slate-700">
          <div className="flex justify-between items-start mb-6">
              <div>
                  <h2 className="text-2xl font-bold flex items-center gap-3 text-slate-900 dark:text-white">
                      <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-lg"><Bus className="text-blue-600 dark:text-blue-400" size={24} /></div>
                      Route Planner
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Live IoT data calculates the smartest transport link.</p>
              </div>
              <button onClick={() => setShowWallet(true)} className="flex items-center gap-2 text-sm font-bold bg-slate-100 dark:bg-slate-700 px-4 py-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors text-slate-700 dark:text-slate-300">
                  <Wallet size={16} /> Wallet
              </button>
          </div>

          {/* Location Selectors */}
          <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Origin</label>
                  <select 
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-sm"
                      value={fromLoc} onChange={e => setFromLoc(e.target.value)}
                  >
                      {cityLocations.map(l => <option key={`orig-${l}`} value={l}>{l}</option>)}
                  </select>
              </div>
              <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Destination</label>
                  <select 
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-sm"
                      value={toLoc} onChange={e => setToLoc(e.target.value)}
                  >
                      {cityLocations.map(l => <option key={`dest-${l}`} value={l}>{l}</option>)}
                  </select>
              </div>
          </div>

          {isSameLocation ? (
              <div className="text-center p-8 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold">
                  Origin and Destination are identical.
              </div>
          ) : (
          <div className="space-y-4 animate-in fade-in">
            
            {/* 1. Primary Metro Route */}
            {isMetroAvailable && (
            <div className={`border p-4 rounded-xl flex flex-col xl:flex-row justify-between xl:items-center gap-4 ${isDestinationCongested ? 'border-red-300 bg-red-50 dark:border-red-900/50 dark:bg-red-900/20 opacity-60' : 'border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-900/50'}`}>
              <div className="flex items-center gap-4 w-full">
                <div className={`p-3 rounded-full ${isDestinationCongested ? 'bg-red-200 text-red-700 dark:bg-red-800 dark:text-red-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}>
                   <Train size={24} />
                </div>
                <div className="flex-1">
                    <h4 className={`font-bold ${isDestinationCongested ? 'text-red-800 dark:text-red-300 text-base line-through' : 'text-slate-800 dark:text-slate-200'}`}>City Metro (Line A)</h4>
                    {isDestinationCongested ? (
                        <p className="text-xs text-red-600 dark:text-red-400 mt-1 font-bold">Severe IoT Alert at {toLoc}. Restricted.</p>
                    ) : (
                        <div className="flex justify-between w-full pr-4">
                            <p className="text-xs text-green-600 dark:text-green-400 mt-1 font-bold flex items-center gap-1"><Zap size={12}/> Fastest Route ({timeMod} mins)</p>
                            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{distance} km</span>
                        </div>
                    )}
                </div>
              </div>
              
              {!isDestinationCongested && (
                  <button onClick={() => handleBookTicket("City Metro (Line A)", metroPrice)} className="w-full xl:w-auto bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-transform hover:scale-105 shrink-0 shadow-sm">
                      <CreditCard size={16} /> Buy Ticket (${metroPrice.toFixed(2)})
                  </button>
              )}
            </div>
            )}
            
            {/* 2. Relief Shuttle Bus (Promoted during congestion) */}
            <div className={`border p-4 rounded-xl flex flex-col xl:flex-row justify-between xl:items-center gap-4 ${isDestinationCongested ? 'border-green-400 bg-green-50 shadow-lg transform scale-[1.02] transition-transform dark:border-green-800 dark:bg-green-900/20' : 'border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-900/50'}`}>
              <div className="flex items-center gap-4 w-full">
                <div className={`p-3 rounded-full ${isDestinationCongested ? 'bg-green-200 text-green-700 dark:bg-green-800 dark:text-green-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}>
                   <Bus size={24} />
                </div>
                <div className="flex-1">
                    <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        Relief Shuttle Bus {isDestinationCongested && <span className="bg-green-500 text-white text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full animate-pulse">Recommended</span>}
                    </h4>
                    {isDestinationCongested ? (
                        <div className="flex justify-between w-full pr-4">
                            <p className="text-xs text-green-600 dark:text-green-400 mt-1 font-bold">Auto-deployed fleets to bypass {toLoc} congestion.</p>
                            <span className="text-xs font-mono text-green-600">{distance} km</span>
                        </div>
                    ) : (
                        <div className="flex justify-between w-full pr-4">
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-bold">Standard Schedule ({timeMod + 10} mins)</p>
                            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{distance} km</span>
                        </div>
                    )}
                </div>
              </div>
              <button onClick={() => handleBookTicket("Emergency Relief Shuttle", busPrice)} className={`shrink-0 w-full xl:w-auto text-white text-xs font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-transform hover:scale-105 ${isDestinationCongested ? 'bg-green-600 hover:bg-green-500 shadow-md' : 'bg-blue-600 hover:bg-blue-500'}`}>
                  <CreditCard size={16} /> Buy Ticket (${busPrice.toFixed(2)})
              </button>
            </div>

            {/* 3. Electric Taxi Fleet */}
            <div className="border border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-900/50 p-4 rounded-xl flex flex-col xl:flex-row justify-between xl:items-center gap-4">
              <div className="flex items-center gap-4 w-full">
                <div className="p-3 rounded-full bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                   <div className="font-black text-xs text-center leading-tight">EV<br/>TAXI</div>
                </div>
                <div className="flex-1">
                    <h4 className="font-bold text-slate-800 dark:text-slate-200">Autonomous Taxi Fleet</h4>
                    <div className="flex justify-between w-full pr-4 mt-1">
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-bold">Point-to-point (Direct Route - {timeMod - 2} mins)</p>
                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{distance} km</span>
                    </div>
                </div>
              </div>
              <button onClick={() => handleBookTicket("Autonomous Taxi Fare", taxiPrice)} className="shrink-0 w-full xl:w-auto bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-transform hover:scale-105 shadow-sm">
                  <CreditCard size={16} /> Reserve Cab (${taxiPrice.toFixed(2)})
              </button>
            </div>

            {/* 4. Tourist Monorail */}
            {isMonorailAvailable && (
            <div className="border border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-900/50 p-4 rounded-xl flex flex-col xl:flex-row justify-between xl:items-center gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                   <Train size={24} />
                </div>
                <div>
                    <h4 className="font-bold text-slate-800 dark:text-slate-200">Skyway Monorail Tour</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-bold">Scenic slow route (45 mins)</p>
                </div>
              </div>
              <button onClick={() => handleBookTicket("Monorail Tour pass", 4.50)} className="w-full xl:w-auto bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-transform hover:scale-105">
                  <CreditCard size={16} /> Buy Pass ($4.50)
              </button>
            </div>
            )}

          </div>
          )}
        </div>

        {/* Tourist Feedback Survey */}
        <div className="bg-slate-900 dark:bg-slate-950 text-white p-8 rounded-2xl shadow-xl border border-slate-800">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-slate-800 p-3 rounded-lg">
              <ThumbsUp className="text-yellow-400" size={24} />
            </div>
            <h2 className="text-2xl font-bold">Experience Survey</h2>
          </div>
          <p className="text-slate-400 mb-8 text-sm">
            Help local government scale smart city operations. How secure and efficient was your visit today?
          </p>

          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label className="block text-sm font-semibold mb-3">Overall Satisfaction Rating</label>
                    <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map(num => (
                        <button 
                            key={num}
                            type="button"
                            onClick={() => setRating(num)}
                            className={`p-2 rounded-full transition-transform hover:scale-110 ${rating >= num ? 'text-yellow-400' : 'text-slate-600'}`}
                        >
                            <Star fill={rating >= num ? 'currentColor' : 'none'} size={32} />
                        </button>
                    ))}
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-semibold mb-2">What could be improved?</label>
                    <textarea 
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-white min-h-[100px] outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Transport wait times, safety concerns, etc."
                        value={feedbackText}
                        onChange={(e) => setFeedbackText(e.target.value)}
                    ></textarea>
                </div>

                <button 
                  type="submit" 
                  disabled={rating === 0}
                  className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                    <Send size={18} /> Submit via Email
                </button>
            </form>
          ) : (
            <div className="h-full min-h-[250px] flex flex-col items-center justify-center text-center space-y-4 animate-in zoom-in duration-300">
                <div className="w-16 h-16 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center">
                    <ThumbsUp size={32} />
                </div>
                <h3 className="text-xl font-bold text-white">Thank You!</h3>
                <p className="text-slate-400 text-sm max-w-xs">Your quantitative response will be shared with City Planners to improve future IoT deployment.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
