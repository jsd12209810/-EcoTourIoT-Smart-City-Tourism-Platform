import { useState, useEffect } from 'react';
import axios from 'axios';
import { Database, Star, MapPin, Clock, Search, FileText } from 'lucide-react';
import { API_URL } from '../config';

export default function AdminDatabaseLogsView() {
  const [attractions, setAttractions] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [selectedPlaceId, setSelectedPlaceId] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [attrRes, feedRes] = await Promise.all([
            axios.get(`${API_URL}/attractions`),
            axios.get(`${API_URL}/feedback`)
        ]);
        setAttractions(attrRes.data);
        setFeedback(feedRes.data);
        
        setSelectedPlaceId(currentId => {
            if (!currentId && attrRes.data.length > 0) {
                return attrRes.data[0]._id;
            }
            return currentId;
        });
      } catch (err) {
        console.error(err);
      }
    };
    
    fetchData();
    const interval = setInterval(fetchData, 5000); // Polling for logs
    return () => clearInterval(interval);
  }, []);

  const selectedPlace = attractions.find(a => a._id === selectedPlaceId) || attractions[0];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-xl flex items-center gap-4">
          <Database className="text-purple-500" size={32} />
          <div>
            <h2 className="text-2xl font-bold text-white tracking-widest uppercase">Database Logs & Reports</h2>
            <p className="text-slate-400 mt-1">Direct access to MongoDB DataLake: Quantitative Surveys & Historical Traffic Logs.</p>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Historical Traffic Logs Viewer */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-md outline outline-1 outline-slate-100 dark:outline-slate-700 flex flex-col h-[600px]">
          <div className="p-6 border-b border-slate-100 dark:border-slate-700">
              <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-4">
                  <MapPin className="text-blue-500" /> Location Traffic Logs
              </h3>
              
              <div className="relative">
                  <Search className="absolute left-3 top-3 text-slate-400" size={18} />
                  <select 
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-800 dark:text-white focus:ring-2 focus:ring-purple-500"
                      onChange={(e) => setSelectedPlaceId(e.target.value)}
                      value={selectedPlace?._id || ''}
                  >
                      {attractions.map(attr => (
                          <option key={attr._id} value={attr._id}>{attr.name} (DB ID: {attr._id.substring(0,6)}...)</option>
                      ))}
                  </select>
              </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-900/30">
              {selectedPlace?.traffic_logs && selectedPlace.traffic_logs.length > 0 ? (
                  <table className="w-full text-left border-collapse">
                      <thead>
                          <tr className="text-xs uppercase text-slate-400 sticky top-0 bg-slate-50 dark:bg-slate-900/30 backdrop-blur-md">
                              <th className="p-3">Timestamp</th>
                              <th className="p-3">Recorded Peak</th>
                          </tr>
                      </thead>
                      <tbody>
                          {/* Render logs in reverse chronological order */}
                          {[...selectedPlace.traffic_logs].reverse().map((log, idx) => (
                              <tr key={idx} className="border-b border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/50">
                                  <td className="p-3 text-sm text-slate-600 dark:text-slate-300 font-mono">
                                      <Clock size={12} className="inline mr-2" />
                                      {new Date(log.timestamp).toLocaleString()}
                                  </td>
                                  <td className="p-3">
                                      <span className={`px-2 py-1 rounded text-xs font-bold ${log.crowd_level > 80 ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : log.crowd_level > 50 ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'}`}>
                                          {log.crowd_level}% Load
                                      </span>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              ) : (
                  <div className="flex items-center justify-center h-full text-slate-500">No logs generated yet. Await backend ticks.</div>
              )}
          </div>
        </div>

        {/* Quantitative Surveys Viewer */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-md outline outline-1 outline-slate-100 dark:outline-slate-700 flex flex-col h-[600px]">
          <div className="p-6 border-b border-slate-100 dark:border-slate-700">
              <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <FileText className="text-purple-500" /> Quantitative Tourist Surveys
              </h3>
              <p className="text-sm text-slate-500 mt-1">Direct pull from `feedbacks` MongoDB Collection.</p>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 dark:bg-slate-900/30">
              {feedback.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-slate-500">No database surveys submitted yet.</div>
              ) : (
                  feedback.map((fb, idx) => (
                      <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm relative">
                          <div className="flex gap-1 mb-3">
                              {[1,2,3,4,5].map(n => (
                                  <Star key={n} size={16} className={n <= fb.rating ? "text-yellow-400 fill-yellow-400" : "text-slate-300"} />
                              ))}
                          </div>
                          <p className="text-slate-700 dark:text-slate-300 antialiased font-medium italic">"{fb.text}"</p>
                          <div className="text-xs text-slate-400 font-mono mt-4 text-right">
                              {new Date(fb.timestamp).toLocaleString()}
                          </div>
                      </div>
                  ))
              )}
          </div>
        </div>

      </div>
    </div>
  );
}
