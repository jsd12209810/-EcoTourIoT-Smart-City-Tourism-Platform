// Global Configuration File
// Automatically switches to localhost during dev, and your cloud URL on Vercel
export const API_URL = import.meta.env.PROD 
    ? 'https://jai-saideep-ca.malikbusiness.cloud/api' 
    : 'http://localhost:5000/api';
