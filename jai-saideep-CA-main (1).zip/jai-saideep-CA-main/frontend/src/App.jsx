import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import HomeView from './components/HomeView'
import TouristView from './components/TouristView'
import AdminView from './components/AdminView'
import PredictiveAnalyticsView from './components/PredictiveAnalyticsView'
import AdminDatabaseLogsView from './components/AdminDatabaseLogsView'
import MobilityFeedbackView from './components/MobilityFeedbackView'
import KioskView from './components/KioskView'
import { Navigation, Menu, Moon, Sun, Lock } from 'lucide-react'

function TopNav({ isDarkMode, setIsDarkMode, isLoggedIn }) {
  const location = useLocation();
  const path = location.pathname;

  return (
    <nav className="bg-slate-900 dark:bg-slate-950 text-white shadow-lg border-b border-transparent dark:border-slate-800 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <Navigation className="text-blue-400" size={24} />
          <span className="text-xl font-bold tracking-tight">EcoTourIoT</span>
        </Link>
        
        <div className="hidden lg:flex gap-2 items-center text-sm font-semibold">
          <Link to="/tourist" className={`px-4 py-2 rounded-md transition-colors ${path === '/tourist' ? 'bg-blue-600' : 'hover:bg-slate-800'}`}>Tourist Live Map</Link>
          <Link to="/mobility" className={`px-4 py-2 rounded-md transition-colors ${path === '/mobility' ? 'bg-green-600' : 'hover:bg-slate-800'}`}>Smart Mobility & Wallet</Link>
          <div className="h-6 w-px bg-slate-700 mx-1"></div>
          
          <Link to="/kiosk" target="_blank" className="px-4 py-2 rounded-md transition-colors hover:bg-slate-800 text-yellow-400 font-bold flex items-center gap-2">Signage Screen</Link>
          <div className="h-6 w-px bg-slate-700 mx-1"></div>

          {!isLoggedIn ? (
            <Link to="/auth" className={`px-4 py-2 rounded-md transition-colors flex items-center gap-1 ${path === '/auth' ? 'bg-purple-600' : 'hover:bg-slate-800'}`}><Lock size={16} /> Admin Portal</Link>
          ) : (
            <>
              <Link to="/admin" className={`px-4 py-2 rounded-md transition-colors ${path === '/admin' ? 'bg-purple-600' : 'hover:bg-slate-800'}`}>Overview</Link>
              <Link to="/admin/analytics" className={`px-4 py-2 rounded-md transition-colors ${path === '/admin/analytics' ? 'bg-purple-600' : 'hover:bg-slate-800'}`}>AI</Link>
              <Link to="/admin/logs" className={`px-4 py-2 rounded-md transition-colors ${path === '/admin/logs' ? 'bg-purple-600' : 'hover:bg-slate-800'}`}>DB Logs</Link>
            </>
          )}

          <div className="h-6 w-px bg-slate-700 mx-1"></div>
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-2 rounded-full hover:bg-slate-800 transition-colors text-yellow-400">
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>

        <button className="lg:hidden p-2 text-slate-300 hover:text-white">
          <Menu size={24} />
        </button>
      </div>
    </nav>
  );
}

function LoginRoute({ setIsLoggedIn }) {
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsLoggedIn(true);
      setLoginError(false);
      navigate('/admin');
    } else {
      setLoginError(true);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 bg-white dark:bg-slate-800 p-8 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xl animate-in fade-in zoom-in-95 duration-300">
      <div className="flex justify-center mb-6">
        <div className="bg-purple-100 dark:bg-purple-900/30 p-4 rounded-full">
          <Lock className="text-purple-600 dark:text-purple-400" size={32} />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-center text-slate-800 dark:text-white mb-2">Restricted Access</h2>
      <p className="text-center text-slate-500 dark:text-slate-400 mb-8 text-sm">Please log in to access DMO tools and predictive analytics.</p>

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <input type="password" placeholder="Enter Admin Password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-3 outline-none text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500" />
          {loginError && <p className="text-red-500 text-xs mt-2 font-medium">Invalid password! Try again</p>}
        </div>
        <button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg transition-colors">
          Login to DMO Network
        </button>
      </form>
    </div>
  );
}

// Higher Order Component to protect Admin routes
function ProtectedRoute({ isLoggedIn, children }) {
  if (!isLoggedIn) {
    return <Navigate to="/auth" replace />;
  }
  return children;
}

function MainApp() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const navigate = useNavigate();

  // Toggle Dark Mode globally
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [isDarkMode])

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <TopNav isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} isLoggedIn={isLoggedIn} />

      <main className="container mx-auto p-4 py-8 relative">
        <Routes>
          <Route path="/" element={<HomeView onGetStarted={() => navigate('/tourist')} />} />
          <Route path="/tourist" element={<TouristView />} />
          <Route path="/mobility" element={<MobilityFeedbackView />} />
          <Route path="/kiosk" element={<KioskView />} />
          <Route path="/auth" element={
            isLoggedIn ? <Navigate to="/admin" replace /> : <LoginRoute setIsLoggedIn={setIsLoggedIn} />
          } />

          <Route path="/admin" element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <AdminView />
            </ProtectedRoute>
          } />
          <Route path="/admin/analytics" element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <PredictiveAnalyticsView />
            </ProtectedRoute>
          } />
          <Route path="/admin/logs" element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <AdminDatabaseLogsView />
            </ProtectedRoute>
          } />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <MainApp />
    </BrowserRouter>
  )
}

export default App
