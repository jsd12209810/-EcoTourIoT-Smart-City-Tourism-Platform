const mongoose = require('mongoose');

const attractionSchema = new mongoose.Schema({
  name: { type: String, required: true },
  image_url: { type: String },
  description: { type: String },
  current_crowd_level: {
    type: Number,
    default: 0
  },
  traffic_logs: [{
    timestamp: { type: Date, default: Date.now },
    crowd_level: Number
  }],
  max_capacity: { type: Number, default: 1000 },
});

module.exports = mongoose.model('Attraction', attractionSchema);
