const https = require('https');

https.get('https://unsplash.com/s/photos/sagrada-familia', (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
        const match = data.match(/(https:\/\/images\.unsplash\.com\/photo-[a-zA-Z0-9-]+)[^"]*/);
        if (match) {
            console.log("FOUND URL: " + match[1]);
        } else {
            console.log("NOT FOUND");
        }
    });
});
