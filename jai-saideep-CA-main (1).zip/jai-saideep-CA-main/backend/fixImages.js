require('dotenv').config();
const mongoose = require('mongoose');
const Attraction = require('./models/Attraction');

const newImages = {
  "Marina Bay": "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800&auto=format&fit=crop",
  "Sagrada Familia": "https://images.unsplash.com/photo-1558642084-fd07fae5282e?w=800&auto=format&fit=crop",
  "Burj Al Arab": "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&auto=format&fit=crop"
};

mongoose.connect(process.env.MONGO_URI).then(async () => {
    console.log("Connected to DB to fix images...");
    for (const [name, url] of Object.entries(newImages)) {
        await Attraction.updateOne({ name }, { image_url: url });
        console.log(`Updated image for ${name}`);
    }
    console.log("Images fixed successfully!");
    process.exit(0);
}).catch(err => {
    console.error(err);
    process.exit(1);
});
