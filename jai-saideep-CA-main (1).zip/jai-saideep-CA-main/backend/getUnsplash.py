import urllib.request
import json

url = "https://unsplash.com/napi/search/photos?query=sagrada+familia&per_page=1"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as response:
    data = json.loads(response.read().decode())
    photo_url = data['results'][0]['urls']['regular']
    print(photo_url)
