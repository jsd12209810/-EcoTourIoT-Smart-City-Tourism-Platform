const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const Attraction = require('./models/Attraction');
const Alert = require('./models/Alert');
const Feedback = require('./models/Feedback');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// API Routes
app.get('/api/attractions', async (req, res) => {
  try {
    const attractions = await Attraction.find();
    res.json(attractions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/alerts', async (req, res) => {
  try {
    const alerts = await Alert.find().sort({ timestamp: -1 }).limit(20);
    res.json(alerts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/alerts', async (req, res) => {
  try {
    const { message, severity, location } = req.body;
    const newAlert = new Alert({ message, severity, location });
    await newAlert.save();
    res.status(201).json(newAlert);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Seed Initial Data (if db is empty or incomplete)
const seedDB = async () => {
    const count = await Attraction.countDocuments();
    if(count < 10) {
        await Attraction.deleteMany({});
        await Alert.deleteMany({});
        await Attraction.insertMany([
            { name: "Marina Bay", image_url: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800&auto=format&fit=crop", description: "Smart IoT sensor grids monitor crowd flows.", current_crowd_level: 20 },
            { name: "Sagrada Familia", image_url: "https://images.unsplash.com/photo-1558642084-fd07fae5282e?w=800&auto=format&fit=crop", description: "Smart transport applications integrate navigation.", current_crowd_level: 50 },
            { name: "Burj Al Arab", image_url: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&auto=format&fit=crop", description: "Comprehensive IoT platform for tourists.", current_crowd_level: 40 },
            { name: "Airport Terminal 1", image_url: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=800&auto=format&fit=crop", description: "International arrivals hub and fast transit lines." },
            { name: "Central Railway Hub", image_url: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&auto=format&fit=crop", description: "Main domestic train station and metro interchange." },
            { name: "Downtown Financial District", image_url: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&auto=format&fit=crop", description: "Commercial and business center." },
            { name: "University Campus", image_url: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800&auto=format&fit=crop", description: "Academic sector and dormitories." },
            { name: "Tech Park South", image_url: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&auto=format&fit=crop", description: "IT hub and research facilities." },
            { name: "Olympic Stadium", image_url: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&auto=format&fit=crop", description: "Major sporting and concert arena." },
            { name: "Historical Museum Square", image_url: "https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?w=800&auto=format&fit=crop", description: "Cultural heritage and museum district." }
        ]);
        console.log("Seeded database with expanded 10 locations dataset.");
    }
}


// Start Server & Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB Connected');
    seedDB();
    // Feedback API
    app.get('/api/feedback', async (req, res) => {
      try {
        const feedback = await Feedback.find().sort({ timestamp: -1 }).limit(50);
        res.json(feedback);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.post('/api/feedback', async (req, res) => {
      try {
        const { rating, text } = req.body;
        const newFeedback = new Feedback({ rating, text });
        await newFeedback.save();
        res.json(newFeedback);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

    // IoT Simulator
    setInterval(async () => {
      const attractions = await Attraction.find();
      for (let attr of attractions) {
        let change = Math.floor(Math.random() * 21) - 10;
        let newCrowd = Math.max(0, Math.min(100, attr.current_crowd_level + change));
        
        await Attraction.findByIdAndUpdate(attr._id, {
            current_crowd_level: newCrowd,
            $push: {
                traffic_logs: {
                    $each: [{ timestamp: new Date(), crowd_level: newCrowd }],
                    $slice: -50
                }
            }
        });

        // Trigger automatic alert if highly congested
        if (newCrowd > 85) {
          const alertMessage = `${attr.name} is highly congested (${newCrowd}% capacity). Please consider alternative destinations.`;
          // Check if an alert for this location already exists in the last 2 minutes to prevent spam
          const recentAlert = await Alert.findOne({
            location: attr.name,
            timestamp: { $gt: new Date(Date.now() - 2 * 60 * 1000) }
          });
          if (!recentAlert) {
            await Alert.create({ message: alertMessage, severity: 'High', location: attr.name });
            console.log(`[IoT Simulator trigger] High congestion at ${attr.name}`);
          }
        }
      }
      console.log('--- IoT Simulator updated crowd levels ---');
    }, 10000); // run every 10 seconds for demo purposes
  })
  .catch(err => {
    console.error('CRITICAL DATABASE ERROR:', err);
    console.warn('NOTE: Running backend without DB connection in fallback mode is NOT supported in this script. Please provide MONGO_URI in .env');
  });

module.exports = app;
